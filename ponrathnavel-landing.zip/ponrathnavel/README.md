# ponrathnavel.io — Personal Landing Page

Premium personal brand landing page for **Rathnavel Ponnuswami** — Educator, Environmental Engineer, Insurance Advisor, Rotarian & Memoir Writer.

## Stack
- React 18 + Vite 5 + TypeScript
- Tailwind CSS 3
- Framer Motion 11
- Lucide React icons
- Google Fonts: Playfair Display, Cormorant Garamond, Manrope

## Design System
| Token | Value | Use |
|-------|-------|-----|
| Navy 950 | `#060D1A` | Page background |
| Navy 900 | `#0B1A2E` | Section bg |
| Gold 500 | `#C9A84C` | Primary accent |
| Emerald 600 | `#40916C` | Environment accent |
| Ivory 200 | `#F2E6CC` | Body text |

## Quick Start

```bash
# Install dependencies
npm install

# Development server (http://localhost:5173)
npm run dev

# Production build
npm run build

# Preview production build locally
npm run preview
```

## Deploy to Vercel

```bash
npm install -g vercel
vercel
```

## Deploy to GitHub Pages

1. Add to `vite.config.ts`:
   ```ts
   base: '/your-repo-name/'  // or '/' for custom domain
   ```
2. Build: `npm run build`
3. Deploy `dist/` folder via GitHub Actions or manually

## Project Structure

```
ponrathnavel/
├── index.html              # SEO meta, OG tags, font imports
├── public/
│   └── favicon.svg
├── src/
│   ├── main.tsx            # React entry
│   ├── index.css           # Global styles + Tailwind directives
│   └── App.tsx             # All sections (single-file architecture)
├── tailwind.config.js
├── vite.config.ts
└── tsconfig.json
```

## Sections
1. **Navigation** — Glassmorphic, scroll-aware, mobile drawer
2. **Hero** — Cinematic, mouse-parallax doodles, stagger animation
3. **Credibility Strip** — 5 achievement cards
4. **About** — Split layout with detail grid
5. **Journey** — Vertical animated timeline
6. **Pillars** — 4 domain cards (Education, Environment, Insurance, Memoirs)
7. **Experience Highlights** — 5 role cards
8. **Social Connect** — 5 platform cards with brand colors
9. **Final CTA** — LinkedIn + email buttons
10. **Footer** — Copyright + social icons
